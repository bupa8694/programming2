"""
Solutions to exam tasks for module 4
"""
# A9
def dice(n,sides):
    from random import choice
    return [choice(range(1,sides+1)) for _ in range(n)]

def throw_dice(ns,n_sides):
    pass 

# A10
def make_list(lst):
    pass

# B4
def count_letters():
    pass

def main():
    print('Test of A9')
    print(throw_dice([8,9,2,10,3,1],6))  # will probably not yield a good 
                                         # approximation of 1/6, since too few throws
    print(throw_dice([100000,100000],20)) # should yield approximately 1/20=0.05

    print('\nTest of A10')
    print(make_list([[1,7,8],[9],[3,3],[1]])) # should print [1, 7, 8, 9, 3, 3, 1]


    print('\nTest of B4')
    count_letters()

if __name__ == "__main__":
    main()
    print('Over and out')
