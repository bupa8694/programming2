"""
Solutions to exam tasks for module 3.

"""
import random
import time


class LinkedList:
    class Node:
        def __init__(self, data, succ=None):
            self.data = data
            self.succ = succ
    
    def __init__(self):                
        self.first = None
    
    def __iter__(self):
        current = self.first
        while current:
            yield current.data
            current = current.succ
    
    def __str__(self):
        if self.first is None:
            return '()'
        res = ''
        for x in self:
            res += str(x) + ', '
        return '(' + res[:-2] + ')'

    
    def append(self, x):                  
        if self.first == None:
            self.first = self.Node(x)
        else:
            node = self.first
            while node.succ:
                node = node.succ
            node.succ = self.Node(x)
    
    def append_better(self, x):                # Task A5
        pass  


def random_tree(n):                            # Task A6 
    t = BST()
    for x in range(n):
        t.insert(random.random())
    return t
"""
Answer to A6 (Complexity of random_tree)



"""


class BST:
    class Node:
        def __init__(self, key, left=None, right=None):
            self.key = key
            self.left = left
            self.right = right

        def __iter__(self):
            if self.left:
                yield from self.left
            yield self.key
            if self.right:
                yield from self.right

    def __init__(self, param=None):
        self.root = None
        if param:
            for x in param:
                self.insert(x)

    def __iter__(self):
        if self.root:
            yield from self.root

    def insert(self, key):
        self.root = self._insert(self.root, key)

    def _insert(self, r, key):
        if r is None:
            return self.Node(key)
        elif key < r.key:
            r.left = self._insert(r.left, key)
        elif key > r.key:
            r.right = self._insert(r.right, key)
        else:
            pass  # Already there
        return r

    def __str__(self):
        result = ''
        for x in self:
            result += str(x) + ', '
        if self.root:
            result = result[:-2]
        return '<' + result + '>'
    
    def size(self):
        result = 0
        for x in self:
            result += 1
        return result

    def epl(self):                          # Task A7
        pass
    
    def __eq__(self, other):                  # Task A8
        pass
    
    def equal(self, other):                   # Task B3
        pass
            



def main():
    print('Trying append_better')
    print('====================')
    ll = LinkedList()
    print('Empty list:', ll)
    for i in range(5):
        ll.append_better(i)
    print('After some appends   : ', ll)
    ll.append_better('x')
    print('After one more append: ', ll)



    print('\nTrying epl')
    print('============')
    t = BST()
    print(f'{t.epl()} should be 1')
    t = BST([1])
    print(f'{t.epl()} should be 4')
    t = BST([1, 2])
    print(f'{t.epl()} should be 8')
    t = BST([1, 2, 3])
    print(f'{t.epl()} should be 13')
    t = BST([2, 1, 3])
    print(f'{t.epl()} should be 12')
    t = BST([2, 1, 3, 4])
    print(f'{t.epl()} should be 17')
        
    print('\nTrying ==')
    print('=========')
    t1 = BST([1,2,3])
    t2 = BST([2,1,3])
    t3 = BST([3,1,2,4])
    t4 = BST([1,2,3,4])
    print(f'{t1} == {t2} : {t1==t2}')
    print(f'{t1} == {t3} : {t1==t3}')
    print(f'{t3} == {t4} : {t3==t4}')    
    print(f'equal: {t1.equal(t2)}')
    
    print('\nTrying equal')
    print('============')
    t5 = BST([1,2])
    t6 = BST(['1, 2'])
    print(f't5 : {t5}, t5.size(): {t5.size()}')
    print(f't6 : {t6}, t6.size(): {t6.size()}')
    print(f't5.equal(t6): {t5.equal(t6)}')
        
if __name__ == '__main__':
    main()
