"""
Solutions to module 1
Student: 
Mail:
Reviewed by:
Reviewed date:
"""

import random
import time


def power(x, n):         # Optional
    pass


def multiply(m, n):      # Compulsory
    pass


def divide(t, n):        # Optional
    pass


def harmonic(n):         # Compulsory
    pass


def digit_sum(x):        # Optional
    pass


def get_binary(x):       # Optional
    pass


def reverse(s):          # Optional
    pass


def largest(a):          # Compulsory
    pass


def count(x, s):         # Compulsory
    pass
    

def zippa(l1, l2):       # Compulsory
    pass


def bricklek(f, t, h, n): # Compulsory
    pass


def main():
    """ Demonstates my implementations """
    # Write your demonstration code here
    print('Bye!')
    

if __name__ == "__main__":
    main()
    
####################################################    
    
"""
  Answers to the none-coding tasks
  ================================
  
  
  Exercise 15: Time for bricklek with 50 bricks:
  
  
  
  
  
  
  Exercise 16: Time for Fibonacci:
  
  
  
  
  
  Exercise 19: Comparison sorting methods:
  
  
  
  
  
  Exercise 20: Comparison Theta(n) and Theta(n log n)
  
  
  
  
  
  
  





"""