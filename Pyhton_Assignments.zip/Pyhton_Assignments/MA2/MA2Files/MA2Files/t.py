import io
lines = tuple(open('MA2test.txt', 'r'))
print(lines)